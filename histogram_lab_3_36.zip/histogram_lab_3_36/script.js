var dataPromise = d3.json("classData.json")

//Read data & format
var reformatData = function(dataP){
  //This function is called at the bottom of the code.
  dataSet = {}
    dataP.then(function(data){
      data.forEach(function(peng){
        peng.quizes.forEach(function(quiz){
          var day = "day"+quiz.day;
          //console.log("|" + day + "|")
          var grade = quiz.grade;
          if (typeof dataSet[day] === 'undefined') {
              // if the day's score array is not in the dataSet
              dataSet[day] = []; //Initialize an array to store all the scores of the day
              dataSet[day].push(grade);
          }
          else {
            dataSet[day].push(grade);
          }
        });
      });
    })
  return dataSet;
  //dataSet format:
  //  {"day1": [score, score, score], "day2": [score, score, score],...}
  };


//Graph settings
var screenSettings = {
width:700,
height:400
};

var marginSettings = {
  top:20,
  bottom: 30,
  left: 50,
  right: 100
}

//Function settings
var drawChart = function(dataSet, svgSelector, selectedDay, screen, margins)
//This function is called at the bottom of the code.
{

  //Draw a histogram using the selectedDay's info
  console.log("dataSet in drawChart():", dataSet);
  console.log("Accessing the array of 'day1' in the dataSet:", dataSet.day1)
  var graphWidth  = screen.width - margins.left - margins.right;
  var graphHeight = screen.height - margins.top - margins.bottom;
  var borderWidth = 1;

  var xScale = d3.scaleLinear()
                .domain([0, 10])
                .range([0, graphWidth])

  //var yScale = d3.scaleLinear()
                // .domain([0, scoreFrequencies.length])
                // .range([0, graphHeight - 15]);

  var binMaker = d3.histogram()
                    .domain(xScale.domain())
                    .thresholds(xScale.ticks(9));

  day = "day" + selectedDay;
  console.log("Day,", day);
  console.log("Using datase:", dataSet.day);
  var bins = binMaker(dataSet.days);
  //@STUCK HERE

  console.log("Input data:",  Object.keys(dataSet));
 console.log("bins:", bins);

  //var yAxisScale = d3.scaleLinear()
                //.domain([0, 100])
                //.range([graphHeight - 15, 0]);

  //var yAxis = d3.axisLeft().scale(yAxisScale);

  var colorScale = d3.scaleOrdinal(d3.schemeAccent);

  //var barWidth = graphWidth / scoreFrequencies.length;
  //
  var graphSVG = d3.select(svgSelector)
              .attr("width", screen.width)
              .attr("height", screen.height);

  graphBorder = graphSVG.append("rect")
                  .attr("border-style", "solid")
                  .attr("x", margins.left)
                  .attr("y", margins.top)
                  .attr("width", graphWidth)
                  .attr("height", graphHeight)
                  .attr("fill", "white")
                  .style("stroke", "black")
                  .style("stroke-width", borderWidth)
                  .classed("graph-border", true);

var graphData = graphSVG.append("g")
                  .classed("graph-data", true);

//var graphBars = graphData.selectAll("rect")
                     // .data(scoreFrequencies)
                     // .enter()
                     // .append("rect")
                     // .attr("width", barWidth)
                     // .attr("height", function(d){console.log("Loop"); return 10;})

                    //  .attr("width", barWidth)
                    //  .attr("height", function(peng){
                    //                   console.log(peng[selectedDay]);
                    //                   return yScale(peng[selectedDay])})
                    //  .attr("x", function(d,i)
                    //  { return margins.left + i*barWidth + (graphWidth/16);})//adjusting the center of bar
                    //  .attr("y", function(person){
                    //                   return graphHeight + margins.top- yScale(peng[selectedDay]) - 2})
                    // .attr("fill", function(person){return colorScale(person.name)})
                    // .style("stroke", "#EBFCFB")
                    // .style("stroke-width", 2)
                    // .classed("data-bar", true);

  };

//Main process
var refinedData = reformatData(dataPromise);
console.log("-------Data from reformatData()-----");
console.log("refinedData", refinedData)

drawChart(refinedData, "#histogram", 1, screenSettings, marginSettings);

//Next: Set the buckets
